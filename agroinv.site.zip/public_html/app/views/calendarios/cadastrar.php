<?php 
    $data = new \DateTime($dados['data'], new \DateTimeZone('America/Sao_Paulo')); 
?>
<header>
    <!-- Caminho relativo para o CSS -->
    <link rel="stylesheet" href="/css/cadastroaula.css" type="text/css">
</header>

<body>
<div class="container my-5">
    <div aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/calendarios/calendarioAdm">Calendário</a></li>
            <li class="breadcrumb-item active" aria-current="page">Cadastrar</li>
        </ol>
    </div>
</div>
<section class="card">
    <form name="formAdd" id="formAdd" method="post" action="/calendarios/cadastrar/<?=$data->format('Y-m-d\TH:i:sP')?>">
        <h2 class="form-title">Formulário de Cadastro de Aula</h2>

        <div class="form-group <?= isset($dados['data_erro']) ? 'is-invalid' : '' ?>">
            <label for="date">Data:<sup class="text-danger">*</sup></label>
            <input type="date" name="date" id="date" value="<?= $data->format('Y-m-d'); ?>" class="form-control" required>
            <div class="invalid-feedback"><?= $dados['data_erro'] ?? '' ?></div>
        </div>

        <div class="form-group <?= isset($dados['start_erro']) ? 'is-invalid' : '' ?>">
            <label for="start">Hora Início:<sup class="text-danger">*</sup></label>
            <input type="time" class="form-control" name="start" id="start" value="<?= $data->format('H:i'); ?>" required>
        </div>

        <div class="form-group <?= isset($dados['end_erro']) ? 'is-invalid' : '' ?>">
            <label for="end">Hora Fim:<sup class="text-danger">*</sup></label>
            <input type="time" class="form-control" name="end" id="end" value="">
        </div>

        <div class="form-group <?= isset($dados['title_erro']) ? 'is-invalid' : '' ?>">
            <label for="title">Título Aula:<sup class="text-danger">*</sup></label>
            <input type="text" name="title" id="title" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="nome_turma">Turma: <sup class="text-danger">*</sup></label>
            <select name="nome_turma" id="nome_turma" class="form-control" required>
                <option value="">Selecione uma turma</option>
                <?php foreach ($dados["turmas"] as $turma): ?>
                    <option value="<?= $turma->nome_turma ?>"><?= $turma->nome_turma ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="nome_professor">Professor: <sup class="text-danger">*</sup></label>
            <select name="nome_professor" id="nome_professor" class="form-control" required>
                <option value="">Selecione um professor</option>
                <?php foreach ($dados["professores"] as $prof): ?>
                    <option value="<?= $prof->nome_usuario ?>"><?= $prof->nome_usuario ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="laboratorio">Laboratório: <sup class="text-danger">*</sup></label>
            <select name="laboratorio" id="laboratorio" class="form-control" required>
                <option value="">Selecione um laboratório</option>
                <option value="Laboratorio 1">Laboratório 1 - Planificação</option>
                <option value="Laboratorio 2">Laboratório 2 - Vegetais</option>
                <option value="Laboratorio 3">Laboratório 3 - Carnes</option>
                <option value="Laboratorio 4">Laboratório 4 - Leite</option>
                <option value="Laboratorio 5">Laboratório 5 - Sala de Aula</option>
            </select>
        </div>

        <div class="form-group">
            <label for="description">Materiais:<sup class="text-danger">*</sup></label>
            <input type="text" class="form-control" name="description" id="description" placeholder="Ex: 10L de leite, 10Kg de milho..." required>
        </div>

        <div class="form-group">
            <label for="docs">Protocolo da aula:<sup class="text-danger">*</sup></label>
            <input type="url" class="form-control" name="docs" id="docs" placeholder="Insira o link do protocolo" required>
        </div>

        <button type="submit" class="btn btn-primary">Marcar Aula</button>
    </form>
</section>
</body>