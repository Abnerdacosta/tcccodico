<footer>
<link rel="stylesheet" href="/css/rodape.css" type="text/css">
    <div class="container-fluid">
        <small>
             <?php echo APP_NOME." ".APP_VERSAO;?>
        </small>
        <div class="border-top mt-3">
            &COPY; 2021 - <?php echo date('Y'); ?>
        </div>       
    </div>
<footer>