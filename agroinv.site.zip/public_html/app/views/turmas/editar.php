<header>
    <link rel="stylesheet" href="/AgroInv/public/css/editarturma.css" type="text/css">
    <script>
        function validarQuantidade(input) {
            if (input.value < 1) {
                input.setCustomValidity("A quantidade deve ser pelo menos 1");
                input.value = 1; // Corrige automaticamente para o valor mínimo
            } else {
                input.setCustomValidity("");
            }
        }
    </script>
</header>
<div class="col-xl-4 col-md-6 mx-auto p-5">
    <div aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo URL ?>/usuarios/gerenciarturmas">Turmas</a></li>
            <li class="breadcrumb-item active" aria-current="page"><a>Editar</a></li>
        </ol>
    </div>
    <div class="card">
        <card class="card-header bg-secondary text-white">
            Editar Turmas
        </card>
        <div class="card-body">
            <form name="editar" method="POST" action="<?php echo URL ?>/turmas/editar/<?= $dados['id'] ?>">

                <!-- Campo Turma (alterado para input text) -->
                <div class="form-group">
                    <label for="nome_turma">Turma: <sup class="text-danger">*</sup></label>
                    <input type="text" name="nome_turma" id="nome_turma" 
                           class="form-control <?= isset($dados['nome_turma_erro']) && $dados['nome_turma_erro'] ? 'is-invalid' : '' ?>" 
                           value="<?= $dados['nome_turma'] ?? '' ?>">
                    <div class="invalid-feedback">
                        <?= $dados['nome_turma_erro'] ?? '' ?>
                    </div>
                </div>

                <!-- Campo Ano Ingresso -->
                <div class="form-group">
                    <label for="ano_ingresso">Ano de Ingresso: <sup class="text-danger">*</sup></label>
                    <input type="text" name="ano_ingresso" id="ano_ingresso" 
                           class="form-control <?= isset($dados['ano_ingresso_erro']) && $dados['ano_ingresso_erro'] ? 'is-invalid' : '' ?>" 
                           maxlength="4" value="<?= $dados['ano_ingresso'] ?? '' ?>">
                    <div class="invalid-feedback">
                        <?= $dados['ano_ingresso_erro'] ?? '' ?>
                    </div>
                </div>

                <!-- Campo Quantidade Alunos com validação reforçada -->
                <div class="form-group">
                    <label for="quantidade_alunos">Quantidade de Alunos: <sup class="text-danger">*</sup></label>
                    <input type="number" name="quantidade_alunos" id="quantidade_alunos" 
                           class="form-control <?= isset($dados['quantidade_alunos_erro']) && $dados['quantidade_alunos_erro'] ? 'is-invalid' : '' ?>" 
                           min="1" oninput="validarQuantidade(this)"
                           value="<?= $dados['quantidade_alunos'] ?? '' ?>">
                    <div class="invalid-feedback">
                        <?= $dados['quantidade_alunos_erro'] ?? 'A quantidade deve ser pelo menos 1' ?>
                    </div>
                </div>

                <div class="form-group">
                    <input type="submit" value="Editar" class="btn btn-info btn-block">
                </div>
            </form>
        </div>
    </div>
</div>