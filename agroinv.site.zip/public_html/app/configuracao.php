<?php 

// Caminho base para a aplicação
define('APP', dirname(__FILE__)); 

// URL base do aplicativo (ajuste conforme o domínio do servidor)
define('URL', 'https://agroinv.site'); 

// Informações do aplicativo
define('APP_NOME', 'AgroInv');
define('APP_VERSAO', '1.0');

// Configuração do banco de dados
define('DB_HOST', '193.203.175.173'); // Ou "nome do servidor"
define('DB_USER', 'u727884664_agroinv'); // Substitua pelo seu usuário do banco
define('DB_PASS', 'AgroInv123'); // Insira a senha configurada no painel
define('DB_NAME', 'u727884664_projetomvc'); // Nome do banco de dados criado no painel

// Defina a URL base para o ambiente de desenvolvimento local e produção
define('BASE_URL', (isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] === 'localhost') ? 'http://localhost/AgroInv' : 'https://agroinv.site');